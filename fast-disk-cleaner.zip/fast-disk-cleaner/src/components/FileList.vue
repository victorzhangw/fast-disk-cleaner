<template>
  <div class="file-list">
    <!-- Header row -->
    <div class="fl-header">
      <div class="col-icon" />
      <div class="col-name">Name</div>
      <div class="col-size">Size</div>
      <div class="col-files">Files</div>
      <div class="col-modified">Modified</div>
      <div class="col-bar">Usage</div>
      <div class="col-actions" />
    </div>

    <!-- Loading skeleton -->
    <template v-if="isLoading">
      <div class="fl-row skeleton-row" v-for="i in 12" :key="i">
        <div class="col-icon"><span class="skeleton icon-skel" /></div>
        <div class="col-name"><span class="skeleton" :style="`width:${60 + i * 7}px;height:12px`" /></div>
        <div class="col-size"><span class="skeleton" style="width:52px;height:12px" /></div>
        <div class="col-files"><span class="skeleton" style="width:36px;height:12px" /></div>
        <div class="col-modified"><span class="skeleton" style="width:100px;height:12px" /></div>
        <div class="col-bar"><span class="skeleton" style="width:100%;height:6px;border-radius:3px" /></div>
        <div class="col-actions" />
      </div>
    </template>

    <!-- Empty state -->
    <div class="fl-empty" v-else-if="entries.length === 0">
      <span class="dim mono">[ empty directory ]</span>
    </div>

    <!-- File rows -->
    <template v-else>
      <div
        v-for="entry in entries"
        :key="entry.path"
        class="fl-row"
        :class="{ selected: selected.has(entry.path) }"
        @click="toggleSelect(entry)"
        @dblclick="entry.is_dir && $emit('navigate', entry.path)"
      >
        <div class="col-icon">
          <span class="icon">{{ entry.is_dir ? "📁" : fileIcon(entry.name) }}</span>
        </div>

        <div class="col-name">
          <span
            class="entry-name"
            :class="{ 'dir-name': entry.is_dir }"
            @click.stop="entry.is_dir && $emit('navigate', entry.path)"
          >{{ entry.name }}</span>
        </div>

        <div class="col-size mono">
          <span :class="sizeClass(entry.size)">{{ formatBytes(entry.size) }}</span>
        </div>

        <div class="col-files mono dim">{{ entry.file_count.toLocaleString() }}</div>

        <div class="col-modified dim mono" style="font-size:11px">
          {{ formatDate(entry.modified) }}
        </div>

        <!-- Proportional size bar -->
        <div class="col-bar">
          <div class="size-bar-track">
            <div
              class="size-bar-fill"
              :style="{
                width: barWidth(entry.size) + '%',
                background: barColor(entry.size),
              }"
            />
          </div>
        </div>

        <!-- Action buttons (appear on hover) -->
        <div class="col-actions" @click.stop>
          <button class="btn-icon" title="Move to Trash" @click="$emit('trash', entry.path)">🗑</button>
          <button class="btn-icon btn-icon-danger" title="Delete Forever" @click="confirmDelete(entry)">✕</button>
        </div>
      </div>
    </template>

    <!-- Batch action bar -->
    <Transition name="slide-up">
      <div class="batch-bar" v-if="selected.size > 0">
        <span class="dim">{{ selected.size }} selected · {{ formatBytes(selectedSize) }}</span>
        <div class="batch-actions">
          <button class="btn-ghost" @click="selected.clear()">Deselect</button>
          <button class="btn-ghost" @click="$emit('trash-batch', [...selected])">
            🗑 Move to Trash
          </button>
          <button class="btn-danger" @click="$emit('delete-batch', [...selected])">
            ✕ Delete Forever
          </button>
        </div>
      </div>
    </Transition>

    <!-- Delete confirmation modal -->
    <Teleport to="body">
      <div class="modal-overlay" v-if="confirmEntry" @click="confirmEntry = null">
        <div class="modal" @click.stop>
          <h3 class="modal-title">⚠ Permanent Delete</h3>
          <p class="dim" style="margin:12px 0">
            This cannot be undone.  Are you sure you want to permanently delete:
          </p>
          <p class="mono amber" style="word-break:break-all">{{ confirmEntry.path }}</p>
          <p class="dim" style="margin-top:6px;font-size:11px">{{ formatBytes(confirmEntry.size) }}</p>
          <div class="modal-actions">
            <button class="btn-ghost" @click="confirmEntry = null">Cancel</button>
            <button class="btn-danger" @click="doDelete">Delete Forever</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from "vue";
import type { FileEntry } from "../composables/useScanner";
import { formatBytes, formatDate } from "../composables/useScanner";

const props = defineProps<{
  entries: FileEntry[];
  isLoading: boolean;
}>();

const emit = defineEmits<{
  navigate:      [path: string];
  trash:         [path: string];
  "trash-batch": [paths: string[]];
  delete:        [path: string];
  "delete-batch":[paths: string[]];
}>();

// ── Selection ─────────────────────────────────────────────────────────────────
const selected = ref(new Set<string>());

function toggleSelect(entry: FileEntry) {
  if (selected.value.has(entry.path)) {
    selected.value.delete(entry.path);
  } else {
    selected.value.add(entry.path);
  }
}

const selectedSize = computed(() =>
  props.entries
    .filter((e) => selected.value.has(e.path))
    .reduce((s, e) => s + e.size, 0)
);

// ── Delete confirmation ────────────────────────────────────────────────────────
const confirmEntry = ref<FileEntry | null>(null);

function confirmDelete(entry: FileEntry) {
  confirmEntry.value = entry;
}

function doDelete() {
  if (confirmEntry.value) {
    emit("delete", confirmEntry.value.path);
    confirmEntry.value = null;
  }
}

// ── Size bar helpers ──────────────────────────────────────────────────────────
const maxSize = computed(() =>
  props.entries.reduce((m, e) => Math.max(m, e.size), 1)
);

function barWidth(size: number): number {
  return (size / maxSize.value) * 100;
}

function barColor(size: number): string {
  const pct = size / maxSize.value;
  if (pct > 0.6) return "var(--amber)";
  if (pct > 0.3) return "var(--blue)";
  return "var(--text-3)";
}

function sizeClass(size: number): string {
  const pct = size / maxSize.value;
  if (pct > 0.6) return "amber";
  return "";
}

// ── File type icons ────────────────────────────────────────────────────────────
function fileIcon(name: string): string {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    rs: "🦀", ts: "📘", js: "📒", vue: "💚",
    zip: "📦", tar: "📦", gz: "📦", rar: "📦", "7z": "📦",
    mp4: "🎬", mkv: "🎬", avi: "🎬", mov: "🎬",
    mp3: "🎵", flac: "🎵", wav: "🎵",
    png: "🖼", jpg: "🖼", jpeg: "🖼", gif: "🖼", webp: "🖼",
    pdf: "📕", doc: "📄", docx: "📄", txt: "📄",
    exe: "⚙", dll: "🔧", so: "🔧",
  };
  return map[ext] ?? "📄";
}
</script>

<style scoped>
.file-list {
  flex: 1;
  overflow-y: auto;
  position: relative;
}

/* ── Header ─────────────────────────────────────────────────────────────── */
.fl-header {
  display: grid;
  grid-template-columns: var(--col-widths);
  padding: 6px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--bg-1);
  position: sticky;
  top: 0;
  z-index: 2;
  font-size: 11px;
  color: var(--text-3);
  text-transform: uppercase;
  letter-spacing: .05em;
}

/* ── Row ────────────────────────────────────────────────────────────────── */
.fl-row {
  display: grid;
  grid-template-columns: var(--col-widths);
  padding: 5px 12px;
  border-bottom: 1px solid var(--border);
  align-items: center;
  cursor: default;
  transition: background 0.1s;
  user-select: none;
}
.fl-row:hover { background: var(--bg-2); }
.fl-row.selected { background: var(--amber-glow); }

/* grid column sizing */
.fl-header, .fl-row {
  --col-widths: 28px 1fr 90px 70px 140px 120px 72px;
}

.col-icon   { font-size: 14px; }
.col-name   { overflow: hidden; padding-right: 8px; }
.col-size   { text-align: right; font-size: 12px; }
.col-files  { text-align: right; font-size: 11px; }
.col-modified { font-size: 11px; }
.col-bar    { padding: 0 8px; }
.col-actions {
  display: flex;
  gap: 4px;
  justify-content: flex-end;
  opacity: 0;
  transition: opacity 0.1s;
}
.fl-row:hover .col-actions { opacity: 1; }

/* ── Entry name ────────────────────────────────────────────────────────── */
.entry-name {
  font-size: 13px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
}
.dir-name {
  cursor: pointer;
  color: var(--text-1);
}
.dir-name:hover { color: var(--amber); text-decoration: underline; }

/* ── Size bar ───────────────────────────────────────────────────────────── */
.size-bar-track {
  height: 4px;
  background: var(--bg-3);
  border-radius: 2px;
  overflow: hidden;
}
.size-bar-fill {
  height: 100%;
  border-radius: 2px;
  transition: width 0.3s ease;
}

/* ── Action buttons ─────────────────────────────────────────────────────── */
.btn-icon {
  background: transparent;
  border: 1px solid var(--border);
  border-radius: 3px;
  padding: 2px 6px;
  font-size: 12px;
  color: var(--text-2);
  cursor: pointer;
  transition: all 0.1s;
}
.btn-icon:hover { background: var(--bg-3); border-color: var(--border-hi); }
.btn-icon-danger:hover { background: rgba(255,77,109,.15); border-color: var(--red); color: var(--red); }

/* ── Empty / skeleton ───────────────────────────────────────────────────── */
.fl-empty {
  display: flex;
  justify-content: center;
  padding: 60px;
  font-size: 12px;
}
.skeleton-row { pointer-events: none; }
.icon-skel { display: inline-block; width: 16px; height: 16px; border-radius: 2px; }

/* ── Batch bar ──────────────────────────────────────────────────────────── */
.batch-bar {
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  background: var(--bg-2);
  border-top: 1px solid var(--amber-dim);
  box-shadow: 0 -4px 20px rgba(0,0,0,.5);
  z-index: 10;
  font-size: 12px;
}
.batch-actions { display: flex; gap: 8px; }

/* transition */
.slide-up-enter-active, .slide-up-leave-active { transition: transform 0.2s, opacity 0.2s; }
.slide-up-enter-from, .slide-up-leave-to { transform: translateY(100%); opacity: 0; }

/* ── Modal ──────────────────────────────────────────────────────────────── */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
}
.modal {
  background: var(--bg-2);
  border: 1px solid var(--border-hi);
  border-radius: 6px;
  padding: 24px;
  max-width: 480px;
  width: 90%;
  box-shadow: 0 20px 60px rgba(0,0,0,.8);
}
.modal-title { color: var(--red); font-size: 15px; font-weight: 600; }
.modal-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: 20px;
}
</style>
