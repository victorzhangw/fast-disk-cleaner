<template>
  <div class="disk-usage" v-if="info">
    <div class="du-label">
      <span class="mono dim">{{ info.path }}</span>
      <span class="mono">
        <span class="amber">{{ formatBytes(info.used) }}</span>
        <span class="dim"> / {{ formatBytes(info.total) }}</span>
      </span>
    </div>
    <div class="du-bar-track">
      <div
        class="du-bar-fill"
        :style="{ width: pct + '%', background: barColor }"
      />
    </div>
    <div class="du-sub">
      <span class="dim">{{ formatBytes(info.available) }} free</span>
      <span class="dim">{{ pct.toFixed(1) }}% used</span>
    </div>
  </div>

  <!-- Skeleton while loading -->
  <div class="disk-usage" v-else>
    <div class="du-label">
      <span class="skeleton" style="width:120px;height:12px" />
      <span class="skeleton" style="width:80px;height:12px" />
    </div>
    <div class="du-bar-track">
      <div class="du-bar-fill skeleton" style="width:60%;background:none" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from "vue";
import type { DiskInfo } from "../composables/useScanner";
import { formatBytes } from "../composables/useScanner";

const props = defineProps<{ info: DiskInfo | null }>();

const pct = computed(() => {
  if (!props.info || props.info.total === 0) return 0;
  return (props.info.used / props.info.total) * 100;
});

const barColor = computed(() => {
  const p = pct.value;
  if (p >= 90) return "var(--red)";
  if (p >= 70) return "var(--amber)";
  return "var(--green)";
});
</script>

<style scoped>
.disk-usage {
  padding: 10px 16px;
  border-bottom: 1px solid var(--border);
  background: var(--bg-1);
}
.du-label {
  display: flex;
  justify-content: space-between;
  font-size: 11px;
  margin-bottom: 6px;
}
.du-bar-track {
  height: 4px;
  background: var(--bg-3);
  border-radius: 2px;
  overflow: hidden;
}
.du-bar-fill {
  height: 100%;
  border-radius: 2px;
  transition: width 0.4s ease, background 0.3s;
}
.du-sub {
  display: flex;
  justify-content: space-between;
  font-size: 11px;
  margin-top: 4px;
}
</style>
