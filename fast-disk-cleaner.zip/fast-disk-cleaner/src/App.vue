<template>
  <div class="app">
    <!-- ── Title bar (custom, because window is undecorated) ──────────────── -->
    <header class="title-bar" data-tauri-drag-region>
      <div class="tb-left">
        <span class="tb-logo">⚡</span>
        <span class="tb-name mono">FastDiskCleaner</span>
      </div>

      <!-- Path input + breadcrumbs -->
      <div class="tb-path">
        <button class="btn-icon-sm" title="Up" @click="goUp" :disabled="breadcrumbs.length <= 1">↑</button>
        <div class="breadcrumbs">
          <template v-for="(crumb, i) in breadcrumbs" :key="crumb">
            <span class="crumb-sep" v-if="i > 0">›</span>
            <button
              class="crumb"
              :class="{ active: i === breadcrumbs.length - 1 }"
              @click="navigateTo(crumb)"
            >{{ crumbLabel(crumb, i) }}</button>
          </template>
        </div>
        <input
          class="path-input"
          v-model="pathInput"
          @keydown.enter="navigateTo(pathInput)"
          placeholder="Enter path…"
          spellcheck="false"
        />
        <button class="btn-primary" style="font-size:11px" @click="navigateTo(pathInput)">Go</button>
      </div>

      <!-- Window controls -->
      <div class="tb-controls">
        <button class="wc-btn" @click="appWindow.minimize()">─</button>
        <button class="wc-btn" @click="appWindow.toggleMaximize()">□</button>
        <button class="wc-btn wc-close" @click="appWindow.close()">✕</button>
      </div>
    </header>

    <!-- ── Tab bar ────────────────────────────────────────────────────────── -->
    <nav class="tab-bar">
      <button
        class="tab"
        :class="{ active: activeTab === 'browser' }"
        @click="activeTab = 'browser'"
      >📂 Browser</button>
      <button
        class="tab"
        :class="{ active: activeTab === 'deep' }"
        @click="activeTab = 'deep'"
      >🔬 Deep Scan</button>
      <button
        class="tab"
        :class="{ active: activeTab === 'trash' }"
        @click="activeTab = 'trash'"
      >🗑 Trash</button>
    </nav>

    <!-- ── Disk usage bar ─────────────────────────────────────────────────── -->
    <DiskUsage :info="diskInfo" />

    <!-- ── Main content ───────────────────────────────────────────────────── -->
    <main class="main-content">

      <!-- BROWSER tab -->
      <template v-if="activeTab === 'browser'">
        <!-- Toolbar -->
        <div class="content-toolbar">
          <span class="dim mono" style="font-size:11px">
            {{ entries.length.toLocaleString() }} items
          </span>
          <div class="toolbar-actions">
            <button class="btn-ghost" @click="navigateTo(currentPath)">↻ Refresh</button>
          </div>
        </div>

        <FileList
          :entries="entries"
          :is-loading="isLoading"
          @navigate="navigateTo"
          @trash="handleTrash"
          @trash-batch="handleTrashBatch"
          @delete="handleDelete"
          @delete-batch="handleDeleteBatch"
        />
      </template>

      <!-- DEEP SCAN tab -->
      <template v-else-if="activeTab === 'deep'">
        <div class="deep-toolbar">
          <div>
            <span class="dim">Scanning: </span>
            <span class="mono amber">{{ currentPath }}</span>
          </div>
          <div class="toolbar-actions">
            <span class="dim mono" v-if="isDeepScanning" style="font-size:11px">
              <span class="scanning-dot" />
              {{ deepProcessed.toLocaleString() }} items found…
            </span>
            <span class="dim mono" v-else-if="sortedDeepEntries.length > 0" style="font-size:11px">
              {{ sortedDeepEntries.length.toLocaleString() }} items (showing top 500 by size)
            </span>
            <button class="btn-primary" v-if="!isDeepScanning" @click="startDeepScan">
              ▶ Start Deep Scan
            </button>
            <button class="btn-ghost" v-else @click="cancelDeepScan">
              ■ Cancel
            </button>
          </div>
        </div>

        <FileList
          :entries="sortedDeepEntries"
          :is-loading="isDeepScanning && sortedDeepEntries.length === 0"
          @navigate="navigateTo"
          @trash="handleTrash"
          @trash-batch="handleTrashBatch"
          @delete="handleDelete"
          @delete-batch="handleDeleteBatch"
        />
      </template>

      <!-- TRASH tab -->
      <template v-else-if="activeTab === 'trash'">
        <TrashManager />
      </template>
    </main>

    <!-- ── Status bar ─────────────────────────────────────────────────────── -->
    <footer class="status-bar">
      <span class="mono dim" style="font-size:11px">
        <span v-if="isLoading"><span class="scanning-dot" /> Loading…</span>
        <span v-else-if="lastAction" class="green">✓ {{ lastAction }}</span>
        <span v-else>Ready</span>
      </span>
      <span class="mono dim" style="font-size:11px">{{ currentPath }}</span>
    </footer>

    <!-- ── Global error toast ─────────────────────────────────────────────── -->
    <Transition name="fade">
      <div class="error-toast" v-if="error">
        <span class="red">⚠ {{ error }}</span>
        <button class="btn-icon-sm" @click="error = null">✕</button>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from "vue";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { invoke } from "@tauri-apps/api/core";

import DiskUsage    from "./components/DiskUsage.vue";
import FileList     from "./components/FileList.vue";
import TrashManager from "./components/TrashManager.vue";

import { useScanner } from "./composables/useScanner";

const appWindow = getCurrentWindow();

const {
  currentPath,
  entries,
  breadcrumbs,
  isLoading,
  isDeepScanning,
  sortedDeepEntries,
  deepProcessed,
  diskInfo,
  error,
  navigateTo,
  goUp,
  startDeepScan,
  cancelDeepScan,
  deleteFast,
  trashItem,
} = useScanner();

const activeTab  = ref<"browser" | "deep" | "trash">("browser");
const pathInput  = ref("C:\\");
const lastAction = ref("");

// Sync path input with navigation
watch(currentPath, (p) => (pathInput.value = p));

// ── Handlers ──────────────────────────────────────────────────────────────────

async function handleTrash(path: string) {
  try {
    await trashItem(path);
    lastAction.value = `Moved to trash: ${path.split("\\").pop() ?? path}`;
  } catch (e) {
    error.value = String(e);
  }
}

async function handleTrashBatch(paths: string[]) {
  try {
    for (const p of paths) await trashItem(p);
    lastAction.value = `Moved ${paths.length} items to trash`;
  } catch (e) {
    error.value = String(e);
  }
}

async function handleDelete(path: string) {
  try {
    await deleteFast(path);
    lastAction.value = `Deleted: ${path.split("\\").pop() ?? path}`;
  } catch (e) {
    error.value = String(e);
  }
}

async function handleDeleteBatch(paths: string[]) {
  try {
    const results = await invoke<{ path: string; success: boolean; error: string | null }[]>(
      "batch_delete",
      { paths }
    );
    const failed = results.filter((r) => !r.success);
    if (failed.length > 0) {
      error.value = `${failed.length} delete(s) failed`;
    } else {
      lastAction.value = `Deleted ${results.length} items`;
    }
  } catch (e) {
    error.value = String(e);
  }
}

// ── Breadcrumb helpers ────────────────────────────────────────────────────────

function crumbLabel(crumb: string, idx: number): string {
  if (idx === 0) {
    // Windows: "C:\" → "C:", Linux: "/" → "/"
    return crumb.endsWith("\\") ? crumb.slice(0, -1) : crumb || "/";
  }
  return crumb.split(/[\\/]/).filter(Boolean).pop() ?? crumb;
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────

onMounted(() => {
  // Default: scan C:\ on Windows, / on Unix
  const defaultPath = navigator.userAgent.includes("Win") ? "C:\\" : "/";
  pathInput.value = defaultPath;
  navigateTo(defaultPath);
});
</script>

<style scoped>
.app {
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
  background: var(--bg-0);
}

/* ── Title bar ───────────────────────────────────────────────────────────── */
.title-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 12px;
  height: 40px;
  background: var(--bg-1);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
  user-select: none;
}

.tb-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}
.tb-logo { font-size: 16px; }
.tb-name { font-size: 13px; font-weight: 600; color: var(--amber); }

.tb-path {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}

.breadcrumbs {
  display: flex;
  align-items: center;
  gap: 2px;
  overflow: hidden;
  flex: 1;
}
.crumb {
  background: none;
  border: none;
  padding: 2px 4px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-2);
  cursor: pointer;
  border-radius: 2px;
  transition: color 0.1s;
  white-space: nowrap;
}
.crumb:hover { color: var(--amber); }
.crumb.active { color: var(--text-1); }
.crumb-sep { color: var(--text-3); font-size: 10px; }

.path-input {
  width: 200px;
  flex-shrink: 0;
}

.tb-controls {
  display: flex;
  gap: 2px;
  flex-shrink: 0;
  margin-left: auto;
}
.wc-btn {
  background: none;
  border: none;
  color: var(--text-2);
  width: 28px;
  height: 28px;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: background 0.1s;
}
.wc-btn:hover { background: var(--bg-3); color: var(--text-1); }
.wc-close:hover { background: var(--red) !important; color: white; }

.btn-icon-sm {
  background: none;
  border: 1px solid var(--border);
  color: var(--text-2);
  padding: 3px 8px;
  border-radius: 3px;
  font-size: 12px;
  cursor: pointer;
}
.btn-icon-sm:hover:not(:disabled) { border-color: var(--border-hi); color: var(--text-1); }
.btn-icon-sm:disabled { opacity: 0.3; cursor: not-allowed; }

/* ── Tab bar ─────────────────────────────────────────────────────────────── */
.tab-bar {
  display: flex;
  padding: 0 12px;
  background: var(--bg-1);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.tab {
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  padding: 8px 14px;
  font-size: 12px;
  color: var(--text-2);
  cursor: pointer;
  transition: color 0.15s, border-color 0.15s;
}
.tab:hover { color: var(--text-1); }
.tab.active { color: var(--amber); border-bottom-color: var(--amber); }

/* ── Main content ────────────────────────────────────────────────────────── */
.main-content {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  background: var(--bg-0);
}

.content-toolbar, .deep-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 16px;
  border-bottom: 1px solid var(--border);
  background: var(--bg-1);
  flex-shrink: 0;
}
.toolbar-actions { display: flex; align-items: center; gap: 8px; }

/* ── Status bar ──────────────────────────────────────────────────────────── */
.status-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 12px;
  background: var(--bg-1);
  border-top: 1px solid var(--border);
  flex-shrink: 0;
}

/* ── Error toast ─────────────────────────────────────────────────────────── */
.error-toast {
  position: fixed;
  bottom: 36px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--bg-2);
  border: 1px solid var(--red);
  border-radius: 6px;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,.6);
  z-index: 200;
}

.fade-enter-active, .fade-leave-active { transition: opacity 0.2s, transform 0.2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; transform: translateX(-50%) translateY(10px); }
</style>
