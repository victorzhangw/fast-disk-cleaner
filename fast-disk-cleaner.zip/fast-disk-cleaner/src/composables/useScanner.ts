import { ref, computed } from "vue";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";

// ── Types (mirroring Rust models) ─────────────────────────────────────────────

export interface FileEntry {
  path: string;
  name: string;
  size: number;
  is_dir: boolean;
  file_count: number;
  modified: string | null;
}

export interface TrashEntry {
  trash_id: string;
  original_path: string;
  name: string;
  size: number;
  deleted_at: string;
}

export interface DiskInfo {
  path: string;
  total: number;
  available: number;
  used: number;
}

export interface DeleteResult {
  path: string;
  success: boolean;
  error: string | null;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const exp = Math.min(Math.floor(Math.log2(bytes) / 10), units.length - 1);
  const val = bytes / Math.pow(1024, exp);
  return `${val.toFixed(exp === 0 ? 0 : 1)} ${units[exp]}`;
}

export function formatDate(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

// ── Composable ────────────────────────────────────────────────────────────────

export function useScanner() {
  // ── State ──────────────────────────────────────────────────────────────────
  const currentPath    = ref<string>("C:\\");
  const entries        = ref<FileEntry[]>([]);
  const breadcrumbs    = ref<string[]>([]);
  const isLoading      = ref(false);
  const isDeepScanning = ref(false);
  const deepEntries    = ref<FileEntry[]>([]);
  const deepProcessed  = ref(0);
  const diskInfo       = ref<DiskInfo | null>(null);
  const error          = ref<string | null>(null);

  let unlistenChunk:    UnlistenFn | null = null;
  let unlistenComplete: UnlistenFn | null = null;

  // ── Computed ───────────────────────────────────────────────────────────────
  const sortedDeepEntries = computed(() =>
    [...deepEntries.value].sort((a, b) => b.size - a.size).slice(0, 500)
  );

  // ── Actions ────────────────────────────────────────────────────────────────

  /** Navigate into a directory and load its immediate children. */
  async function navigateTo(path: string) {
    isLoading.value = true;
    error.value     = null;

    try {
      entries.value = await invoke<FileEntry[]>("scan_directory", { path });
      currentPath.value = path;
      rebuildBreadcrumbs(path);
      await loadDiskInfo(path);
    } catch (e) {
      error.value = String(e);
    } finally {
      isLoading.value = false;
    }
  }

  /** Go up one directory level. */
  function goUp() {
    const sep = currentPath.value.includes("/") ? "/" : "\\";
    const parts = currentPath.value.split(sep).filter(Boolean);
    if (parts.length <= 1) return;
    parts.pop();

    let parent: string;
    if (currentPath.value.startsWith("/")) {
      parent = "/" + parts.join("/");
    } else {
      // Windows: "C:\\Users" → "C:\\"
      parent = parts.join("\\") + (parts.length === 1 ? "\\" : "");
    }

    navigateTo(parent);
  }

  /** Start a deep scan and stream results via events. */
  async function startDeepScan() {
    deepEntries.value  = [];
    deepProcessed.value = 0;
    isDeepScanning.value = true;
    error.value = null;

    // Clean up any previous listeners
    unlistenChunk?.();
    unlistenComplete?.();

    unlistenChunk = await listen<{ entries: FileEntry[]; processed: number }>(
      "scan-chunk",
      ({ payload }) => {
        deepEntries.value.push(...payload.entries);
        deepProcessed.value = payload.processed;
      }
    );

    unlistenComplete = await listen("scan-complete", () => {
      isDeepScanning.value = false;
    });

    try {
      await invoke("start_deep_scan", { path: currentPath.value });
    } catch (e) {
      error.value = String(e);
      isDeepScanning.value = false;
    }
  }

  /** Cancel an in-progress deep scan. */
  async function cancelDeepScan() {
    await invoke("cancel_scan");
    isDeepScanning.value = false;
  }

  /** Delete a path instantly (rename + background removal). */
  async function deleteFast(path: string) {
    await invoke("delete_fast", { path });
    entries.value = entries.value.filter((e) => e.path !== path);
  }

  /** Move a path to the custom trash. */
  async function trashItem(path: string): Promise<TrashEntry> {
    const entry = await invoke<TrashEntry>("trash_item", { path });
    entries.value = entries.value.filter((e) => e.path !== path);
    return entry;
  }

  // ── Disk info ──────────────────────────────────────────────────────────────

  async function loadDiskInfo(path: string) {
    try {
      diskInfo.value = await invoke<DiskInfo>("get_disk_info", { path });
    } catch {
      diskInfo.value = null; // non-fatal
    }
  }

  // ── Breadcrumbs ────────────────────────────────────────────────────────────

  function rebuildBreadcrumbs(path: string) {
    const isWin = path.match(/^[A-Za-z]:\\/);
    if (isWin) {
      const parts = path.split("\\").filter(Boolean);
      breadcrumbs.value = parts.map((_, i) =>
        parts.slice(0, i + 1).join("\\") + (i === 0 ? "\\" : "")
      );
    } else {
      const parts = path.split("/").filter(Boolean);
      breadcrumbs.value = ["", ...parts].map((_, i) =>
        "/" + parts.slice(0, i).join("/")
      );
    }
  }

  return {
    currentPath,
    entries,
    breadcrumbs,
    isLoading,
    isDeepScanning,
    deepEntries,
    sortedDeepEntries,
    deepProcessed,
    diskInfo,
    error,
    navigateTo,
    goUp,
    startDeepScan,
    cancelDeepScan,
    deleteFast,
    trashItem,
  };
}

// ── Trash composable ──────────────────────────────────────────────────────────

export function useTrash() {
  const items    = ref<TrashEntry[]>([]);
  const isLoading = ref(false);
  const error    = ref<string | null>(null);

  async function load() {
    isLoading.value = true;
    try {
      items.value = await invoke<TrashEntry[]>("list_trash");
    } catch (e) {
      error.value = String(e);
    } finally {
      isLoading.value = false;
    }
  }

  async function restore(trash_id: string) {
    await invoke("restore_trash", { trash_id });
    items.value = items.value.filter((i) => i.trash_id !== trash_id);
  }

  async function purge(trash_id: string) {
    await invoke("purge_trash", { trash_id });
    items.value = items.value.filter((i) => i.trash_id !== trash_id);
  }

  async function emptyAll(): Promise<number> {
    const freed = await invoke<number>("empty_trash");
    items.value = [];
    return freed;
  }

  return { items, isLoading, error, load, restore, purge, emptyAll };
}
