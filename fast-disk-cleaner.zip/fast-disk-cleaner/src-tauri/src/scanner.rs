use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use chrono::{DateTime, Utc};
use rayon::prelude::*;
use walkdir::WalkDir;

use crate::models::FileEntry;

// ── Public API ────────────────────────────────────────────────────────────────

/// Scan the **immediate children** of `path` and return them sorted by size
/// (largest first).  Directory sizes are computed recursively, in parallel.
///
/// This is the primary command for the tree-view: click a folder → call this.
pub fn scan_directory(path: &str) -> Result<Vec<FileEntry>, std::io::Error> {
    let dir_iter = std::fs::read_dir(path)?;

    // Collect first so we can use rayon in the next step
    let raw: Vec<std::fs::DirEntry> = dir_iter.filter_map(|e| e.ok()).collect();

    let mut entries: Vec<FileEntry> = raw
        .par_iter()                         // ← real parallelism: metadata reads
        .filter_map(|entry| {
            let meta = entry.metadata().ok()?;
            let path_obj = entry.path();

            let (size, file_count) = if meta.is_dir() {
                // Walk inside each sub-dir (blocking, but in parallel across dirs)
                compute_dir_stats(&path_obj)
            } else {
                (meta.len(), 1)
            };

            Some(FileEntry {
                path: path_obj.display().to_string(),
                name: entry.file_name().to_string_lossy().into_owned(),
                size,
                is_dir: meta.is_dir(),
                file_count,
                modified: system_time_to_rfc3339(meta.modified().ok()),
            })
        })
        .collect();

    entries.sort_unstable_by(|a, b| b.size.cmp(&a.size));
    Ok(entries)
}

/// Deep scan of an entire subtree, streaming results back in chunks via
/// `on_chunk(entries, total_processed)`.
///
/// The walk phase is necessarily single-threaded (WalkDir constraint), but
/// metadata reads on each chunk are parallelised with rayon.
///
/// Pass an `Arc<AtomicBool>` cancel flag; set it to `true` to stop early.
pub fn scan_deep_with_progress(
    path: &str,
    cancel: Arc<AtomicBool>,
    on_chunk: impl Fn(Vec<FileEntry>, u64) + Send + Sync,
) {
    // ── Phase 1: single-threaded directory walk ──────────────────────────────
    let mut all: Vec<walkdir::DirEntry> = Vec::with_capacity(50_000);

    for entry in WalkDir::new(path)
        .follow_links(false)
        .into_iter()
        .filter_map(|e| e.ok())
        .skip(1)                // skip the root itself
    {
        if cancel.load(Ordering::Relaxed) {
            return;
        }
        all.push(entry);
    }

    // ── Phase 2: parallel metadata reads, emitted in chunks ─────────────────
    let total = all.len() as u64;
    let chunk_size = 1_000;
    let mut processed = 0u64;

    for chunk in all.chunks(chunk_size) {
        if cancel.load(Ordering::Relaxed) {
            return;
        }

        let entries: Vec<FileEntry> = chunk
            .par_iter()
            .filter_map(|e| {
                let meta = e.metadata().ok()?;
                Some(FileEntry {
                    path: e.path().display().to_string(),
                    name: e.file_name().to_string_lossy().into_owned(),
                    size: if meta.is_file() { meta.len() } else { 0 },
                    is_dir: meta.is_dir(),
                    file_count: if meta.is_file() { 1 } else { 0 },
                    modified: system_time_to_rfc3339(meta.modified().ok()),
                })
            })
            .collect();

        processed += chunk.len() as u64;
        on_chunk(entries, processed);
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/// Recursively compute (total_bytes, total_files) for a directory.
fn compute_dir_stats(dir: &Path) -> (u64, u64) {
    WalkDir::new(dir)
        .follow_links(false)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter_map(|e| e.metadata().ok())
        .filter(|m| m.is_file())
        .fold((0u64, 0u64), |(bytes, count), m| {
            (bytes + m.len(), count + 1)
        })
}

fn system_time_to_rfc3339(t: Option<std::time::SystemTime>) -> Option<String> {
    t.map(|st| {
        let dt: DateTime<Utc> = st.into();
        dt.to_rfc3339()
    })
}
