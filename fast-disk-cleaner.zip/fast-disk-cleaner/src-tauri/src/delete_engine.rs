use std::fs;
use std::path::Path;
use std::thread;

use rayon::prelude::*;

use crate::models::DeleteResult;

// ── Single delete ─────────────────────────────────────────────────────────────

/// **Ultra-fast delete strategy:**
///
/// 1. Rename the target to `<path>.deleting_<timestamp>` — this is atomic and
///    returns instantly on the same filesystem.
/// 2. Spawn a background thread that calls `remove_dir_all` on the renamed path.
///
/// The caller (and the UI) sees an immediate `Ok(())`.  The actual disk I/O
/// happens behind the scenes.
pub fn ultra_delete(path: &str) -> Result<(), std::io::Error> {
    let src = Path::new(path);

    if !src.exists() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("Path does not exist: {path}"),
        ));
    }

    // Build a unique "in-progress" name so concurrent deletes don't clash.
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();

    let staging = format!("{}.deleting_{}", path, ts);

    // Atomic rename — instant on the same volume.
    fs::rename(src, &staging)?;

    // Background removal — errors are logged but do not propagate to caller.
    thread::spawn(move || {
        if let Err(e) = fs::remove_dir_all(&staging) {
            eprintln!("[delete_engine] background removal failed for {staging}: {e}");

            // Fallback: try file-by-file deletion if remove_dir_all failed
            // (can happen on Windows with locked files).
            let _ = remove_recursive_fallback(Path::new(&staging));
        }
    });

    Ok(())
}

/// Delete a single file (not directory).
pub fn delete_file(path: &str) -> Result<(), std::io::Error> {
    let p = Path::new(path);
    if p.is_dir() {
        ultra_delete(path)
    } else {
        fs::remove_file(p)
    }
}

// ── Batch delete ──────────────────────────────────────────────────────────────

/// Delete multiple paths concurrently with rayon.
/// Returns one `DeleteResult` per input path regardless of success/failure.
pub fn batch_delete(paths: Vec<String>) -> Vec<DeleteResult> {
    paths
        .par_iter()
        .map(|path| match delete_file(path) {
            Ok(_) => DeleteResult {
                path: path.clone(),
                success: true,
                error: None,
            },
            Err(e) => DeleteResult {
                path: path.clone(),
                success: false,
                error: Some(e.to_string()),
            },
        })
        .collect()
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/// Last-resort recursive deletion when `remove_dir_all` fails.
/// Walks the tree and deletes leaf files first, then empty directories.
fn remove_recursive_fallback(path: &Path) -> std::io::Result<()> {
    if path.is_dir() {
        for entry in fs::read_dir(path)? {
            remove_recursive_fallback(&entry?.path())?;
        }
        fs::remove_dir(path)?;
    } else {
        fs::remove_file(path)?;
    }
    Ok(())
}
