mod delete_engine;
mod error;
mod models;
mod scanner;
mod trash;

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use tauri::{AppHandle, Manager, State};

use crate::error::AppError;
use crate::models::{DeleteResult, DiskInfo, FileEntry, TrashEntry};

// ── Shared state ──────────────────────────────────────────────────────────────

/// Holds a cancel flag that can abort an in-progress deep scan.
pub struct ScanState {
    pub cancel_flag: Arc<AtomicBool>,
}

impl Default for ScanState {
    fn default() -> Self {
        Self {
            cancel_flag: Arc::new(AtomicBool::new(false)),
        }
    }
}

// ── Scanner commands ──────────────────────────────────────────────────────────

/// Return the immediate children of `path` sorted by size (largest first).
/// Directory sizes are computed recursively, in parallel.
#[tauri::command]
pub fn scan_directory(path: String) -> Result<Vec<FileEntry>, AppError> {
    scanner::scan_directory(&path).map_err(AppError::from)
}

/// Kick off a deep background scan.  Results are streamed to the frontend
/// via `scan-chunk` events.  A `scan-complete` event fires when done.
///
/// Event payload shapes:
///   `scan-chunk`    → `{ entries: FileEntry[], processed: number }`
///   `scan-complete` → `null`
#[tauri::command]
pub fn start_deep_scan(
    path: String,
    app: AppHandle,
    state: State<'_, ScanState>,
) -> Result<(), AppError> {
    state.cancel_flag.store(false, Ordering::Relaxed);
    let cancel = state.cancel_flag.clone();

    std::thread::spawn(move || {
        scanner::scan_deep_with_progress(&path, cancel, |entries, processed| {
            let _ = app.emit(
                "scan-chunk",
                serde_json::json!({ "entries": entries, "processed": processed }),
            );
        });

        let _ = app.emit("scan-complete", ());
    });

    Ok(())
}

/// Cancel an in-progress deep scan.
#[tauri::command]
pub fn cancel_scan(state: State<'_, ScanState>) {
    state.cancel_flag.store(true, Ordering::Relaxed);
}

// ── Delete commands ───────────────────────────────────────────────────────────

/// Fast-delete: rename + background removal.  Returns immediately.
#[tauri::command]
pub fn delete_fast(path: String) -> Result<(), AppError> {
    delete_engine::ultra_delete(&path).map_err(AppError::from)
}

/// Delete a single file.
#[tauri::command]
pub fn delete_file(path: String) -> Result<(), AppError> {
    delete_engine::delete_file(&path).map_err(AppError::from)
}

/// Delete multiple paths in parallel.
#[tauri::command]
pub fn batch_delete(paths: Vec<String>) -> Vec<DeleteResult> {
    delete_engine::batch_delete(paths)
}

// ── Trash commands ────────────────────────────────────────────────────────────

/// Move a file / folder to the custom trash (recoverable).
#[tauri::command]
pub fn trash_item(path: String) -> Result<TrashEntry, AppError> {
    trash::move_to_trash(&path).map_err(AppError::from)
}

/// List all items in the custom trash.
#[tauri::command]
pub fn list_trash() -> Result<Vec<TrashEntry>, AppError> {
    trash::list_trash().map_err(AppError::from)
}

/// Restore a trashed item to its original location.
#[tauri::command]
pub fn restore_trash(trash_id: String) -> Result<String, AppError> {
    trash::restore_from_trash(&trash_id).map_err(AppError::from)
}

/// Permanently remove one item from the trash.
#[tauri::command]
pub fn purge_trash(trash_id: String) -> Result<(), AppError> {
    trash::purge_from_trash(&trash_id).map_err(AppError::from)
}

/// Empty the entire trash; returns bytes freed.
#[tauri::command]
pub fn empty_trash() -> Result<u64, AppError> {
    trash::empty_trash().map_err(AppError::from)
}

// ── Disk info command ─────────────────────────────────────────────────────────

/// Return disk usage information for the volume that contains `path`.
#[tauri::command]
pub fn get_disk_info(path: String) -> Result<DiskInfo, AppError> {
    disk_info(&path)
}

#[cfg(target_os = "windows")]
fn disk_info(path: &str) -> Result<DiskInfo, AppError> {
    use std::os::windows::ffi::OsStrExt;
    use std::ffi::OsStr;

    let wide: Vec<u16> = OsStr::new(path)
        .encode_wide()
        .chain(std::iter::once(0))
        .collect();

    let mut free_bytes: u64 = 0;
    let mut total_bytes: u64 = 0;
    let mut total_free: u64 = 0;

    // SAFETY: calling Windows API with valid pointers
    let ok = unsafe {
        windows_sys::Win32::Storage::FileSystem::GetDiskFreeSpaceExW(
            wide.as_ptr(),
            &mut free_bytes,
            &mut total_bytes,
            &mut total_free,
        )
    };

    if ok == 0 {
        return Err(AppError::Custom("GetDiskFreeSpaceExW failed".into()));
    }

    Ok(DiskInfo {
        path: path.to_string(),
        total: total_bytes,
        available: free_bytes,
        used: total_bytes.saturating_sub(free_bytes),
    })
}

#[cfg(not(target_os = "windows"))]
fn disk_info(path: &str) -> Result<DiskInfo, AppError> {
    use std::ffi::CString;
    use std::mem::MaybeUninit;

    let c_path = CString::new(path).map_err(|e| AppError::Custom(e.to_string()))?;

    // SAFETY: statvfs is a standard POSIX call
    let mut stat: MaybeUninit<libc::statvfs> = MaybeUninit::uninit();
    let ret = unsafe { libc::statvfs(c_path.as_ptr(), stat.as_mut_ptr()) };

    if ret != 0 {
        return Err(AppError::Io(std::io::Error::last_os_error()));
    }

    let stat = unsafe { stat.assume_init() };
    let block = stat.f_frsize as u64;
    let total = stat.f_blocks as u64 * block;
    let available = stat.f_bavail as u64 * block;

    Ok(DiskInfo {
        path: path.to_string(),
        total,
        available,
        used: total.saturating_sub(available),
    })
}

// ── Entry point ───────────────────────────────────────────────────────────────

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(ScanState::default())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![
            // scanner
            scan_directory,
            start_deep_scan,
            cancel_scan,
            // delete
            delete_fast,
            delete_file,
            batch_delete,
            // trash
            trash_item,
            list_trash,
            restore_trash,
            purge_trash,
            empty_trash,
            // disk
            get_disk_info,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
